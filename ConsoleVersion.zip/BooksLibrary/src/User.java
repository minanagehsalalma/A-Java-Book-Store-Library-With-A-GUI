
public class User {

    public Privilege privilege;
    
    public boolean authenticate(String password, User.Privilege privilege) {
        boolean isUserAuthenticated = false;
        if (privilege == User.Privilege.Admin && "admin123".equals(password)) {
            isUserAuthenticated = true;
        }
        return isUserAuthenticated;
    }

    public enum Privilege {
        Admin,
        Customer;

    }
}
