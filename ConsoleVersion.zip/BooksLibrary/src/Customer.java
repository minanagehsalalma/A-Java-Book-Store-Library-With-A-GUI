public class Customer {
    private final Cart cart;
    
    public Customer() {
        cart = new Cart();
    }

}
