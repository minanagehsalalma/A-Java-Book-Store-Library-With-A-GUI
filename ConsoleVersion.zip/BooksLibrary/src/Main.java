import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
public static final List<Book> booksList;
private static Book returnedBook;
    static {
        booksList = new ArrayList<>();
        booksList.add(new Book(1, "The Art Of Not Giviing An F", "Moon Light", 10, 5));
        booksList.add(new Book(2, "TMNT", "Eslam Ninja", 8, 7));
        booksList.add(new Book(3, "Lost is in lost world", "White Tomas", 12, 2));
    }
   
    private static final Book book = new Book();
    private static final Cart cart = new Cart();
    private static final User user = new User(); 

    
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        outerLoop: do {
            System.out.println("Choose if you are an admin or a customer:");
            System.out.println("1. admin");
            System.out.println("2. customer");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter your password: ");
                    String password = scanner.next();
                    while (!user.authenticate(password,User.Privilege.Admin)) {
                        System.out.println("Wrong password. Please try again.");
                        System.out.print("Enter your password: ");
                        password = scanner.next();
                    }
                    int adminChoice;
                    innerLoop1: do {
                        System.out.println("Choose an action:");
                        System.out.println("1. Print all books");
                        System.out.println("2. Remove a book");
                        System.out.println("3. Add a book");
                        System.out.println("4. Go back to the main menu");
                        System.out.print("Enter your choice: ");
                        adminChoice = scanner.nextInt();
                        switch (adminChoice) {
                            case 1:
                                book.printAllBooks(booksList);
                                break;
                            case 2:
                                RemoveBook(User.Privilege.Admin);
                                break;
                            case 3:
                                AddBook(User.Privilege.Admin);
                                break;
                            case 4:
                                break innerLoop1;
                            default:
                                System.out.println("Invalid choice. Please try again.");
                        }
                    } while (true);
                    break;
                case 2:
                    int customerChoice;
                    innerLoop2: do {
                        System.out.println("Choose an action:");
                        System.out.println("1. Print all books");
                        System.out.println("2. Print all books in the cart");
                        System.out.println("3. Add a book to the cart");
                        System.out.println("4. Remove a book from the cart");
                        System.out.println("5. Go back to the main menu");
                        System.out.print("Enter your choice: ");
                        customerChoice = scanner.nextInt();
                        switch (customerChoice) {
                            case 1:
                                book.printAllBooks(booksList);
                                break;
                            case 2:
                                cart.printAllCartBooks();
                                break;
                            case 3:
                                AddBook(User.Privilege.Customer);
                                break;
                            case 4:
                                RemoveBook(User.Privilege.Customer);
                                break;
                            case 5:
                                break innerLoop2;
                            default:
                                System.out.println("Invalid choice. Please try again.");
                        }
                    } while (true);
                    break;
                case 3:
                    break outerLoop;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (true);
        System.out.println("Exiting the program...");
    }
    public static void AddBook(User.Privilege privilege) {
        Scanner scanner = new Scanner(System.in);
        if (privilege == User.Privilege.Admin) {
            System.out.println("Enter book title:");
            String title = scanner.nextLine();
            System.out.println("Enter author name:");
            String author = scanner.nextLine();
            System.out.println("Enter book price:");
            int price = scanner.nextInt();
            System.out.println("Enter book quantity:");
            int quantity = scanner.nextInt();
            Book createdbook = new Book(booksList.size() + 6, title, author, price, quantity);
            book.addBook(createdbook, booksList);
            System.out.println("Book added successfully.");
        } else if (privilege == User.Privilege.Customer) {
            if (cart.VaildateAddingBookToCart()) {
                System.out.print("Enter the ID of the book to add to cart: ");
                int id = scanner.nextInt();
                returnedBook = book.getBookById(id, booksList);
                if (returnedBook != null) {
                    cart.addBookToCart(returnedBook);
                    System.out.println("Book added to cart successfully.");
                } else {
                    System.out.println("Book not found in inventory.");
                }
            } else {
                System.out.println("Sorry, you can't add more than 5 books to your cart.");
            }

        }
    }
    public static void RemoveBook(User.Privilege privilege) {
        Scanner scanner = new Scanner(System.in);
        if (privilege == User.Privilege.Admin) {
            System.out.print("Enter the ID of the book to remove: ");
            int id = scanner.nextInt();
            boolean isBookRemoved = book.removeBook(id, booksList);
            if (isBookRemoved) {
                System.out.println("Book with ID " + id + " has been removed.");
            } else {
                System.out.println("No book found with ID " + id + ".");
            }   
        } else if (privilege == User.Privilege.Customer) {
            System.out.print("Enter the ID of the book to remove from cart: ");
            int id = scanner.nextInt();
            returnedBook = book.getBookById(id, cart.cartBooks);
            if (returnedBook != null) {
                cart.removeBookFromCart(returnedBook);
                System.out.println("Book removed from cart successfully.");
            } else {
                System.out.println("Book not found in cart.");
            }
    }
    }
}    
            

