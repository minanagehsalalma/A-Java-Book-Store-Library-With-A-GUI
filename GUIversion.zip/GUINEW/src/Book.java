import java.util.Iterator;
import java.util.List;

public class Book {
    public int id;
    public String title;
    public String author;
    public int price;
    public int quantity;

    public Book() {
    }

   public Book(int id, String title, String author, double price, int quantity) {
    this.id = id;
    this.title = title;
    this.author = author;
    this.price = (int) price;
    this.quantity = quantity;
}
  
     public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    

    public void addBook(Book book, List<Book> books) {
        books.add(book);
    }

public boolean removeBook(int id, List<Book> books) {
    Iterator<Book> iterator = books.iterator();
    boolean isBookRemoved = false;
    while (iterator.hasNext()) {
        Book book = iterator.next();
        if (book.getId() == id) {
            iterator.remove();
            isBookRemoved = true;
        }
    }
    return isBookRemoved;
}


    public Book getBookById(int id, List<Book> books) {
        for (Book book : books) {
            if (book.getId() == id) {
                return book;
            }
        }
        return null;
    }

//overriding the toString() method to change print output format,Java compiler internally calls it.
    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }
}
