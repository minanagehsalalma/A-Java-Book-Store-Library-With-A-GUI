import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.JOptionPane;
import javax.swing.border.Border;


public class Main extends JFrame {
    private static final List<Book> booksList;
    private static Book returnedBook;
    private static final Book book = new Book();
    private static final Cart cart = new Cart();
    private static final User user = new User();
    private static JFrame adminMenuFrame;
    private static JFrame customerMenuFrame;
    private JButton adminButton;
    private JButton customerButton;
    private JButton exitButton;
    private static JButton printBooksButton;
    private static JButton printCartButton;
    private final JFrame mainMenuFrame;
    private static JTable bookTable;
    private static DefaultTableModel model;
    private static final boolean isRemoveButtonEnabled = false;
    private static final boolean isAddButtonEnabled = true;


    static {
        booksList = new ArrayList<>();
        booksList.add(new Book(1, "The Art Of Not Giving An F", "Moon Light", 10, 5));
        booksList.add(new Book(2, "TMNT", "Eslam Ninja", 8, 7));
        booksList.add(new Book(3, "Lost in Lost World", "White Tomas", 12, 2));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }

    public Main() {
        initComponents();
        initListeners();
        mainMenuFrame = this;
        setTitle("Main Menu");
        setSize(720, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(adminButton);
        panel.add(customerButton);
        panel.add(exitButton);

        setContentPane(panel);

        setVisible(true);
    }

    private void initComponents() {
        adminButton = new JButton("Admin");
        adminButton.setFont(new Font("Arial", Font.PLAIN, 20));
        adminButton.setBackground(Color.BLUE);
        adminButton.setForeground(Color.BLACK);
        Border border = BorderFactory.createLineBorder(Color.BLACK, 2);
        adminButton.setBorder(border);
        adminButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Add a black border
        Font buttonFont = adminButton.getFont();
        Font boldFont = buttonFont.deriveFont(Font.BOLD);
        adminButton.setFont(boldFont);
        adminButton.setFocusPainted(false);
        customerButton = new JButton("Customer");
        customerButton.setFont(new Font("Arial", Font.PLAIN, 20));
        customerButton.setBackground(Color.YELLOW);
        customerButton.setForeground(Color.BLACK);
        customerButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Add a black border
        customerButton.setBorder(border);
        Font buttonFont2 = customerButton.getFont();
        Font boldFon2 = buttonFont2.deriveFont(Font.BOLD);
        customerButton.setFont(boldFon2);
        customerButton.setFocusPainted(false);
        exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Arial", Font.PLAIN, 20));
        exitButton.setBackground(Color.MAGENTA);
        exitButton.setForeground(Color.BLACK);
        exitButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Add a black border
        exitButton.setBorder(border);
        Font buttonFont3 = exitButton.getFont();
        Font boldFont3 = buttonFont3.deriveFont(Font.BOLD);
        exitButton.setFont(boldFont3);
        exitButton.setFocusPainted(false);

        
    }

    private void initListeners() {
    adminButton.addActionListener((ActionEvent e) -> {
        String password = JOptionPane.showInputDialog(mainMenuFrame, "Enter your password:");
        if (password != null) {
            // Prompt the user for password until it is correct
            while (!user.authenticate(password, User.Privilege.Admin)) {
                JOptionPane.showMessageDialog(mainMenuFrame, "Wrong password. Please try again.");
                password = JOptionPane.showInputDialog(mainMenuFrame, "Enter your password:");
                if (password == null) {
                    // User clicked cancel or closed the dialog
                    return;
                }
            }
            showAdminMenu();
        }
    });

        customerButton.addActionListener((ActionEvent e) -> {
            showCustomerMenu();
        });

        exitButton.addActionListener((ActionEvent e) -> {
            System.exit(0);
        });
    }
    
private void showAdminMenu() {
    adminMenuFrame = new JFrame("Admin Menu");
    adminMenuFrame.setSize(900, 600);
    adminMenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    adminMenuFrame.setLocationRelativeTo(null);

    // Create a table model with columns for the book data
    String[] columnNames = { "ID", "Title", "Author", "Price", "Quantity" };
    model = new DefaultTableModel(columnNames, 0);

    // Create a JTable with the table model
    bookTable = new JTable(model);
    bookTable.setFont(new Font("Arial", Font.PLAIN, 20));

    // Set the column widths
    bookTable.getColumnModel().getColumn(0).setPreferredWidth(50); // ID column
    bookTable.getColumnModel().getColumn(1).setPreferredWidth(400); // Title column
    bookTable.getColumnModel().getColumn(2).setPreferredWidth(200); // Author column
    bookTable.getColumnModel().getColumn(3).setPreferredWidth(100); // Price column
    bookTable.getColumnModel().getColumn(4).setPreferredWidth(100); // Quantity column

    // Increase the row height for better visibility
    bookTable.setRowHeight(30);

    // Set font for the table headers
    JTableHeader header = bookTable.getTableHeader();
    header.setFont(new Font("Arial", Font.BOLD, 18));

    // Add the table to a scroll pane and add the scroll pane to the frame
    JScrollPane scrollPane = new JScrollPane(bookTable);
    adminMenuFrame.add(scrollPane, BorderLayout.CENTER);

    // Create a panel to hold the buttons
    JPanel buttonPanel = new JPanel(new GridLayout(1, 3));

    // Create a button to print all books
    printBooksButton = new JButton("Print All Books");
    printBooksButton.setFont(new Font("Arial", Font.PLAIN, 18));
    printBooksButton.setPreferredSize(new Dimension(200, 40));
    printBooksButton.setBackground(Color.BLUE);
    printBooksButton.setForeground(Color.BLACK);
    printBooksButton.addActionListener(e -> {
        model.setRowCount(0);
        for (Book book : booksList) {
            Object[] rowData = {book.getId(), book.getTitle(), book.getAuthor(), book.getPrice(), book.getQuantity()};
            model.addRow(rowData);
        }
    });
    buttonPanel.add(printBooksButton);


    // Create a button to remove a book
    JButton removeBookButton = new JButton("Remove Book");
    removeBookButton.setFont(new Font("Arial", Font.PLAIN, 18));
    removeBookButton.setPreferredSize(new Dimension(200, 40));
    removeBookButton.setBackground(Color.GREEN);
    removeBookButton.setForeground(Color.BLACK);
    removeBookButton.addActionListener(e -> {
        RemoveBook(User.Privilege.Admin); // Call the method to remove a book
    });
    buttonPanel.add(removeBookButton);

    // Create a button to add a book
    JButton addBookButton = new JButton("Add Book");
    addBookButton.setFont(new Font("Arial", Font.PLAIN, 18));
    addBookButton.setPreferredSize(new Dimension(200, 40));
    addBookButton.setBackground(Color.YELLOW);
    addBookButton.setForeground(Color.BLACK);
    addBookButton.addActionListener(e -> {
        AddBook(User.Privilege.Admin); // Call the method to add a book
    });
    buttonPanel.add(addBookButton);

    // Create a button to go back to the main menu
    JButton mainMenuButton = new JButton("Main Menu");
    mainMenuButton.setFont(new Font("Arial", Font.PLAIN, 18));
    mainMenuButton.setPreferredSize(new Dimension(200, 40));
    mainMenuButton.setBackground(Color.MAGENTA);
    mainMenuButton.setForeground(Color.BLACK);
    mainMenuButton.addActionListener(e -> {
        adminMenuFrame.dispose();
        mainMenuFrame.setVisible(true);
    });
    buttonPanel.add(mainMenuButton);

    // Add the button panel to the frame
    adminMenuFrame.add(buttonPanel, BorderLayout.SOUTH);
        // Hide the main menu frame
    mainMenuFrame.setVisible(false);

    adminMenuFrame.setVisible(true);
    
}


private void showCustomerMenu() {
    // Create the customer menu frame
    customerMenuFrame = new JFrame("Customer Menu");
    customerMenuFrame.setSize(900, 600);
    customerMenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    customerMenuFrame.setLocationRelativeTo(null);

    // Create a table model with columns for the book data
    String[] columnNames = { "ID", "Title", "Author", "Price", "Quantity" };
    model = new DefaultTableModel(columnNames, 0);

    // Create a JTable with the table model
    bookTable = new JTable(model);
    // Set font for the cell renderer
    bookTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            c.setFont(new Font("Arial", Font.PLAIN, 20));
            return c;
        }
    });

    // Set font for the table headers
    JTableHeader header = bookTable.getTableHeader();
    header.setFont(new Font("Arial", Font.BOLD, 18));

    // Set the column widths
    bookTable.getColumnModel().getColumn(0).setPreferredWidth(50); // ID column
    bookTable.getColumnModel().getColumn(1).setPreferredWidth(400); // Title column
    bookTable.getColumnModel().getColumn(2).setPreferredWidth(400); // Author column
    bookTable.getColumnModel().getColumn(3).setPreferredWidth(100); // Price column
    bookTable.getColumnModel().getColumn(4).setPreferredWidth(100); // Quantity column
    bookTable.setRowHeight(30);
    // Add the table to a scroll pane and add the scroll pane to the frame
    JScrollPane scrollPane = new JScrollPane(bookTable);
    customerMenuFrame.add(scrollPane, BorderLayout.CENTER);

    // Create a panel to hold the buttons
    JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
    // Create a button to remove a book
    JButton removeBookButton = new JButton("Remove Book");
    removeBookButton.setFont(new Font("Arial", Font.PLAIN, 18));
    removeBookButton.setBackground(Color.ORANGE);
    removeBookButton.setForeground(Color.BLACK);
    removeBookButton.setEnabled(isRemoveButtonEnabled);
    removeBookButton.addActionListener(e -> {
        RemoveBook(User.Privilege.Customer); // Call the method to remove a book from the cart
    });
        // Create a button to add a book
    JButton addBookButton = new JButton("Add Book");
    addBookButton.setFont(new Font("Arial", Font.PLAIN, 18));
    addBookButton.setBackground(Color.YELLOW);
    addBookButton.setForeground(Color.BLACK);
    addBookButton.setEnabled(isAddButtonEnabled);
    addBookButton.addActionListener(e -> {
        AddBook(User.Privilege.Customer); // Call the method to add a book to the cart
    });
    // Create a button to print all books
    printBooksButton = new JButton("Print All Books");
    printBooksButton.setFont(new Font("Arial", Font.PLAIN, 18));
    printBooksButton.setBackground(Color.BLUE);
    printBooksButton.setForeground(Color.BLACK);
    printBooksButton.addActionListener(e -> {
        model.setRowCount(0);
        // Implement the logic to retrieve and display all books from the booksList in Main
        for (Book book : booksList) {
            Object[] rowData = { book.id, book.title, book.author, book.price, book.quantity };
            model.addRow(rowData);
        }
        removeBookButton.setEnabled(false);
        addBookButton.setEnabled(true);
    });
    buttonPanel.add(printBooksButton);

    buttonPanel.add(addBookButton);


    // Create a button to print all books in cart
 printCartButton = new JButton("Print Cart");
    printCartButton.setFont(new Font("Arial", Font.PLAIN, 18));
    printCartButton.setBackground(Color.GREEN);
    printCartButton.setForeground(Color.BLACK);
    printCartButton.addActionListener(e -> {
        model.setRowCount(0);
        if (cart.cartBooks.isEmpty()) {
            JOptionPane.showMessageDialog(customerMenuFrame, "Your cart is empty.");
        } else {
            for (Book book : cart.cartBooks) {
                Object[] rowData = {book.getId(), book.getTitle(), book.getAuthor(), book.getPrice(), book.getQuantity()};
                model.addRow(rowData);
            }
          // Show the removeBookButton
        removeBookButton.setEnabled(true);
        addBookButton.setEnabled(false);
        }
    });
    buttonPanel.add(printCartButton);


    buttonPanel.add(removeBookButton);

    
    // Create a button to main menu
    JButton mainMenuButton = new JButton("Main Menu");
    mainMenuButton.setFont(new Font("Arial", Font.PLAIN, 18));
    mainMenuButton.setPreferredSize(new Dimension(200, 40));
    mainMenuButton.setBackground(Color.MAGENTA);
    mainMenuButton.setForeground(Color.BLACK);
    mainMenuButton.addActionListener(e -> {
        customerMenuFrame.dispose();
         mainMenuFrame.setVisible(true);
    });
    buttonPanel.add(mainMenuButton);


    // Add the button panel to the frame
    customerMenuFrame.add(buttonPanel, BorderLayout.SOUTH);

    // Hide the main menu frame
    mainMenuFrame.setVisible(false);

    // Show the customer menu frame
    customerMenuFrame.setVisible(true);
}



    public static void RemoveBook(User.Privilege privilege) {
        if (privilege == User.Privilege.Admin) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(adminMenuFrame, "Please select a book to remove.");
                return;
            }

            int id = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
            boolean isBookRemoved = book.removeBook(id, booksList);

            if (isBookRemoved) {
                JOptionPane.showMessageDialog(adminMenuFrame, "Book with ID " + id + " has been removed.");
                printBooksButton.doClick();
            } else {
                JOptionPane.showMessageDialog(adminMenuFrame, "No book found with ID " + id + ".");
            }
        } else if (privilege == User.Privilege.Customer) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(adminMenuFrame, "Please select a book to remove.");
                return;
            }
               int id = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                returnedBook = book.getBookById(id, cart.cartBooks);
                if (returnedBook != null) {
                    cart.removeBookFromCart(returnedBook);
                    JOptionPane.showMessageDialog(customerMenuFrame, "Book removed from cart successfully.");
                    printCartButton.doClick();
                } else {
                    JOptionPane.showMessageDialog(customerMenuFrame, "Book not found in cart.");
                }
            }
        }
   


public static void AddBook(User.Privilege privilege) {
    if (null == privilege) {
        JOptionPane.showMessageDialog(customerMenuFrame, "Sorry, you can't add more than 5 books to your cart.");
    } else switch (privilege) {
            case Admin:
                String title = JOptionPane.showInputDialog(adminMenuFrame, "Enter book title:");
                String author = JOptionPane.showInputDialog(adminMenuFrame, "Enter author name:");
                String priceInput = JOptionPane.showInputDialog(adminMenuFrame, "Enter book price:");
                String quantityInput = JOptionPane.showInputDialog(adminMenuFrame, "Enter book quantity:");
                if (title != null && author != null && priceInput != null && quantityInput != null) {
                    int price = Integer.parseInt(priceInput);
                    int quantity = Integer.parseInt(quantityInput);
                    Book createdbook = new Book((int) (Math.random() * 1000), title, author, price, quantity);
                    book.addBook(createdbook, booksList);
                    JOptionPane.showMessageDialog(adminMenuFrame, "Book added successfully.");
                    printBooksButton.doClick();
                }       break;
            case Customer:
                if (cart.VaildateAddingBookToCart()) {
                    int selectedRow = bookTable.getSelectedRow();
                    if (selectedRow == -1) {
                        JOptionPane.showMessageDialog(adminMenuFrame, "Please select a book to remove.");
                        return;
                    }
                    int id = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                    returnedBook = book.getBookById(id, booksList);
                    if (returnedBook != null) {
                        cart.addBookToCart(returnedBook);
                        JOptionPane.showMessageDialog(customerMenuFrame, "Book added to cart successfully.");
                    } else {
                        JOptionPane.showMessageDialog(customerMenuFrame, "Book not found in inventory.");
                    }
                }  else {
                JOptionPane.showMessageDialog(customerMenuFrame, "Sorry, you can't add more than 5 books to your cart.");
                break;
        }

}
}
}






