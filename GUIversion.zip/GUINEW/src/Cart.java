import java.util.ArrayList;
import java.util.List;

public class Cart {
    public final List<Book> cartBooks;
    private int numBooksInCart;
    
    public Cart() {
        cartBooks = new ArrayList<>();
        numBooksInCart = 0;
    }

    public boolean VaildateAddingBookToCart(){
        boolean isVaild=false;
       if (numBooksInCart < 5) {
           isVaild=true;
       }
     return isVaild;
    }
            
    public void addBookToCart(Book book) {
        cartBooks.add(book);
        numBooksInCart++;
    }

    public void removeBookFromCart(Book book) {
        cartBooks.remove(book);
        numBooksInCart--;
    }

 
}
